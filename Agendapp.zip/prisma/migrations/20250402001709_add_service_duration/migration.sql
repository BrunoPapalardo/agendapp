-- AlterTable
ALTER TABLE "Appointment" ADD COLUMN     "serviceDuration" INTEGER NOT NULL DEFAULT 0;
