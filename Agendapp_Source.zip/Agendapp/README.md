# Documentação do Agendapp

## Visão Geral
O Agendapp é uma aplicação web para agendamento de serviços, desenvolvida com Next.js, React, Prisma e PostgreSQL. A aplicação permite que empresas cadastrem seus serviços e horários de funcionamento, e que clientes agendem serviços com base na disponibilidade.

## Requisitos do Sistema
- Node.js 18.x ou superior
- PostgreSQL 14.x ou superior
- NPM 8.x ou superior

## Dependências Principais
- Next.js 15.1.5 - Framework React para desenvolvimento web
- React 19.0.0 - Biblioteca JavaScript para construção de interfaces
- Prisma 6.3.1 - ORM para acesso ao banco de dados
- NextAuth 4.24.11 - Autenticação para aplicações Next.js
- React Big Calendar 1.18.0 - Componente de calendário para agendamentos
- Date-fns 4.1.0 - Biblioteca para manipulação de datas
- Tailwind CSS 3.4.17 - Framework CSS para estilização
- Lucide React 0.475.0 - Biblioteca de ícones

## Instalação

### 1. Clone o repositório
```bash
git clone <url-do-repositorio>
cd Agendapp
```

### 2. Instale as dependências
```bash
npm install
```

### 3. Configure as variáveis de ambiente
Crie um arquivo `.env` na raiz do projeto com as seguintes variáveis:

```
DATABASE_URL="postgresql://usuario:senha@localhost:5432/agendapp"
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="sua-chave-secreta-para-nextauth"
```

### 4. Configure o banco de dados
```bash
npx prisma migrate dev
```

### 5. Inicie o servidor de desenvolvimento
```bash
npm run dev
```

A aplicação estará disponível em `http://localhost:3000`.

## Estrutura do Projeto

### Diretórios Principais
- `/app` - Páginas e rotas da aplicação (Next.js App Router)
- `/components` - Componentes React reutilizáveis
- `/prisma` - Schema e migrações do Prisma
- `/public` - Arquivos estáticos
- `/lib` - Utilitários e funções auxiliares

### Componentes Principais
- `Calendar` - Componente de calendário para agendamentos
- `BusinessHours` - Configuração de horários de funcionamento
- `Header/SubHeader` - Componentes de navegação
- `Administration` - Painel de administração flutuante

### Páginas Principais
- `/home` - Página inicial com listagem de empresas
- `/business/[businessCode]` - Detalhes da empresa e serviços
- `/login` e `/register` - Autenticação de usuários
- `/[businessCode]/admin` - Área administrativa da empresa

## Funcionalidades

### Para Clientes
1. **Busca de Empresas**: Filtrar por categoria ou nome
2. **Visualização de Serviços**: Ver detalhes, preços e duração
3. **Agendamento**: Selecionar serviço, data e horário disponível
4. **Gerenciamento de Conta**: Login, registro e visualização de agendamentos

### Para Empresas
1. **Gerenciamento de Serviços**: Adicionar, editar e remover serviços
2. **Configuração de Horários**: Definir horários de funcionamento
3. **Gerenciamento de Funcionários**: Associar funcionários a serviços
4. **Visualização de Agendamentos**: Ver agenda e histórico

## Fluxo de Agendamento
1. Cliente seleciona uma empresa na página inicial
2. Na página da empresa, seleciona um serviço
3. Opcionalmente, filtra por funcionário específico
4. Clica em "Agendar" no serviço desejado
5. Seleciona data e horário disponível no calendário
6. Confirma o agendamento (requer login)

## Personalização Mobile-First
A aplicação foi desenvolvida com abordagem mobile-first, garantindo boa experiência em dispositivos móveis:
- Layout responsivo que se adapta a diferentes tamanhos de tela
- Componentes otimizados para toque
- Visualizações simplificadas em telas pequenas

## Solução de Problemas

### Erro de conexão com o banco de dados
Verifique se:
- O PostgreSQL está em execução
- As credenciais no arquivo `.env` estão corretas
- O banco de dados especificado existe

### Erro ao iniciar a aplicação
- Verifique se todas as dependências foram instaladas corretamente
- Certifique-se de que as variáveis de ambiente estão configuradas
- Verifique se não há conflitos de porta (padrão: 3000)

## Próximos Passos
Para desenvolvimento futuro, considere:
1. Implementar notificações por e-mail/SMS
2. Adicionar sistema de avaliações
3. Desenvolver aplicativos nativos para Android e iOS
4. Implementar pagamentos online
