import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

interface Params {
  params: { code: string };
}

// GET request handler to fetch a single company by its code
export async function GET(request: NextRequest, { params }: Params) {
  try {
    const { code } = params; // Extract the code from the dynamic route segment

    if (!code) {
      return NextResponse.json({ error: "Company code is required in the URL path" }, { status: 400 });
    }

    // Fetch the company from the database using the unique code
    const company = await prisma.company.findUnique({
      where: { code: code },
      include: {
        category: true, // Include category details
        services: true, // Include related services
        employees: { // Include related employees
          include: {
            services: true // Optionally include services specific to each employee if needed
          }
        },
        businessHours: true, // Include business hours
      },
    });

    // If company not found, return 404
    if (!company) {
      return NextResponse.json({ error: "Company not found" }, { status: 404 });
    }

    // Return the company data
    return NextResponse.json(company, { status: 200 });

  } catch (error) {
    console.error("Error fetching company by code:", error);
    // Generic error handler
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

