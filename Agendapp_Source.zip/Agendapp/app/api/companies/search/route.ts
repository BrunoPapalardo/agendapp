import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const categoryId = searchParams.get("categoryId");
    const searchTerm = searchParams.get("searchTerm");

    const where: any = {};

    if (categoryId) {
      where.categoryId = parseInt(categoryId);
    }

    if (searchTerm) {
      where.name = {
        contains: searchTerm,
        mode: 'insensitive', // Case-insensitive search
      };
    }

    // Fetch companies with category data included
    const companies = await prisma.company.findMany({
      where,
      include: {
        category: true, // Include category details
      },
      orderBy: {
        name: 'asc',
      },
    });

    // Optionally, fetch all categories separately if needed for filtering UI
    const categories = await prisma.category.findMany({
      orderBy: {
        name: 'asc',
      },
    });

    return NextResponse.json({ companies, categories }, { status: 200 });

  } catch (error) {
    console.error("Error fetching companies:", error);
    // Check if the error is due to invalid categoryId format
    if (error instanceof Error && error.message.includes("Argument `categoryId` must be a number")) {
        return NextResponse.json({ error: "Invalid categoryId format. It must be a number." }, { status: 400 });
    }
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

