'use client';

import Image from "next/image";
import { useEffect, useState, useCallback } from "react";
import { useParams, useRouter } from "next/navigation";
import { MapPin, Clock, Instagram, Phone, MessageCircle, Map, AlertCircle, ArrowLeft, Loader2, Calendar as CalendarIcon, Users, DollarSign, Filter } from "lucide-react";
import Link from "next/link";
import SubHeader from '../../../components/SubHeader/SubHeader';
import ErrorPage from '../../../components/ErrorPage/ErrorPage';
import AgendaModal from "../../../components/Calendar/Calendar"; // Import the calendar modal
import FloatingAdministration from "../../../components/Administration/Administration"; // Import admin component

// Define interfaces matching Prisma schema
interface Category {
  id: number;
  name: string;
  icon: string;
}

interface Service {
  id: number;
  name: string;
  companyId: number;
  image: string | null;
  price: number;
  duration: number; // Duration in minutes
  prepareTime: number;
  intervalTime: number;
  employeeIds?: number[]; // IDs of employees who can perform this service
}

interface Employee {
  id: number;
  name: string;
  companyId: number;
  image: string | null;
  services?: Service[]; // Services this employee can perform
}

interface BusinessHours {
  id: number;
  companyId: number;
  employeeId: number | null;
  dayOfWeek: number; // 0 (Sunday) - 6 (Saturday)
  startTime: string; // "HH:mm"
  endTime: string; // "HH:mm"
}

interface CompanyDetails {
  id: number;
  name: string;
  code: string;
  address: string;
  categoryId: number;
  image: string | null;
  telephone: string;
  ispublic: number;
  cnpj: string | null;
  email: string | null;
  instagram: string | null;
  whatsapp: string | null;
  coordinates: string | null;
  category: Category;
  services: Service[];
  employees: Employee[];
  businessHours: BusinessHours[];
  // Add rating if available
  rating?: number;
}

// Helper function to validate image source
const isValidImageSrc = (src: string | null | undefined): src is string => {
  if (!src) return false;
  // Basic check for absolute URL or path starting with /
  return src.startsWith('http://') || src.startsWith('https://') || src.startsWith('/');
};

// Skeleton Loader for the page
function BusinessLoading() {
    return (
        <div className="min-h-screen bg-gray-50 animate-pulse">
            <SubHeader />
            <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-3 sm:py-8">
                {/* Header Skeleton */}
                <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-4 sm:mb-8">
                    <div className="h-40 sm:h-64 w-full bg-gray-200" />
                    <div className="p-3 sm:p-6">
                        <div className="h-5 sm:h-8 w-2/3 bg-gray-300 rounded-md mb-2" />
                        <div className="mt-2 flex items-center text-sm">
                            <MapPin className="flex-shrink-0 mr-1.5 h-3 sm:h-5 w-3 sm:w-5 text-gray-400" />
                            <div className="h-3 sm:h-4 w-1/2 bg-gray-300 rounded-md" />
                        </div>
                        <div className="mt-3 sm:mt-4 flex flex-wrap gap-2 sm:gap-4">
                            <div className="h-4 sm:h-6 w-4 sm:w-6 bg-gray-300 rounded-full" />
                            <div className="h-4 sm:h-6 w-4 sm:w-6 bg-gray-300 rounded-full" />
                            <div className="h-4 sm:h-6 w-4 sm:w-6 bg-gray-300 rounded-full" />
                            <div className="h-4 sm:h-6 w-4 sm:w-6 bg-gray-300 rounded-full" />
                        </div>
                    </div>
                </div>

                {/* Services Skeleton */}
                <div>
                    <div className="h-4 sm:h-6 w-1/3 bg-gray-300 rounded-md mb-3 sm:mb-6" />
                    <div className="grid grid-cols-1 gap-3 sm:gap-6 sm:grid-cols-2 lg:grid-cols-3">
                        {Array.from({ length: 3 }).map((_, index) => (
                            <div key={index} className="bg-white rounded-lg shadow-sm p-3 sm:p-6">
                                <div className="flex items-start">
                                    <div className="h-14 sm:h-20 w-14 sm:w-20 bg-gray-300 rounded-md mr-2 sm:mr-4 flex-shrink-0" />
                                    <div className="flex-grow">
                                        <div className="h-4 sm:h-6 w-3/4 bg-gray-300 rounded-md mb-2" />
                                        <div className="flex items-center text-sm mt-2">
                                            <Clock className="h-3 sm:h-4 w-3 sm:w-4 text-gray-400" />
                                            <div className="h-3 sm:h-4 w-10 sm:w-16 bg-gray-300 rounded-md ml-1" />
                                        </div>
                                        <div className="flex items-center text-sm mt-1">
                                            <DollarSign className="h-3 sm:h-4 w-3 sm:w-4 text-gray-400" />
                                            <div className="h-3 sm:h-4 w-8 sm:w-12 bg-gray-300 rounded-md ml-1" />
                                        </div>
                                        <div className="mt-2 sm:mt-4 h-7 sm:h-10 w-full bg-gray-300 rounded-md" />
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}

function BusinessPage() {
    const params = useParams();
    const businessCode = params.businessCode as string; // Get code from URL
    const router = useRouter();
    const [business, setBusiness] = useState<CompanyDetails | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [showCalendar, setShowCalendar] = useState(false); // State for calendar modal
    const [selectedService, setSelectedService] = useState<Service | null>(null); // State for selected service
    const [selectedEmployeeId, setSelectedEmployeeId] = useState<number | null>(null); // State for employee filter
    const [filteredServices, setFilteredServices] = useState<Service[]>([]);
    const [showEmployeeFilter, setShowEmployeeFilter] = useState(false);

    const fetchBusiness = useCallback(async () => {
        if (!businessCode) return;
        setLoading(true);
        setError(null);
        try {
            // Use the new API route: /api/companies/[code]
            const response = await fetch(`/api/companies/${businessCode}`);

            if (!response.ok) {
                if (response.status === 404) {
                    throw new Error("Estabelecimento não encontrado");
                } else {
                    const errorData = await response.json();
                    throw new Error(errorData.error || `Falha ao buscar dados: ${response.statusText}`);
                }
            }

            const data: CompanyDetails = await response.json();
            setBusiness(data);
            setFilteredServices(data.services);
        } catch (err: any) {
            console.error("Error fetching business details:", err);
            setError(err.message || "Ocorreu um erro desconhecido");
        } finally {
            setLoading(false);
        }
    }, [businessCode]);

    useEffect(() => {
        fetchBusiness();
    }, [fetchBusiness]);

    // Filter services by selected employee
    useEffect(() => {
        if (!business) return;
        
        if (!selectedEmployeeId) {
            setFilteredServices(business.services);
            return;
        }
        
        // Filter services based on employee ID
        // This requires the API to return employeeIds for each service or a similar structure
        const employeeServices = business.services.filter(service => 
            service.employeeIds?.includes(selectedEmployeeId)
        );
        
        // If the selected employee has specific services, show them. Otherwise, show all services.
        // Adjust this logic based on how your API handles employee-service relations.
        setFilteredServices(employeeServices.length > 0 ? employeeServices : business.services);
    }, [selectedEmployeeId, business]);

    const handleScheduleClick = (service: Service) => {
        setSelectedService(service);
        setShowCalendar(true);
    };

    const handleEmployeeSelect = (employeeId: number | null) => {
        setSelectedEmployeeId(employeeId);
        setShowEmployeeFilter(false);
    };

    if (loading) {
        return <BusinessLoading />;
    }

    if (error || !business) {
        return <ErrorPage message={error || "Estabelecimento não encontrado ou código inválido."} />;
    }

    // Helper to format duration (assuming duration is in minutes)
    const formatDuration = (minutes: number) => {
        if (!minutes) return '0min';
        const h = Math.floor(minutes / 60);
        const m = minutes % 60;
        let durationStr = '';
        if (h > 0) durationStr += `${h}h `;
        if (m > 0) durationStr += `${m}min`;
        return durationStr.trim() || '0min';
    };

    const fallbackImage = '/img/logo.png';

    return (
        <div className="min-h-screen bg-gray-50 pb-20 sm:pb-24"> {/* Adjusted padding-bottom for mobile */ }
            <SubHeader />
            <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-3 sm:py-8">
                {/* Business Header */}
                <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-4 sm:mb-8">
                    <div className="h-40 sm:h-64 w-full relative">
                        <Image
                            src={isValidImageSrc(business.image) ? business.image : fallbackImage}
                            alt={business.name}
                            fill
                            sizes="(max-width: 640px) 100vw, (max-width: 1200px) 100vw, 1200px"
                            className="object-cover"
                            priority // Prioritize loading header image
                            onError={(e) => { e.currentTarget.src = fallbackImage; }} // Fallback on error
                        />
                    </div>
                    <div className="p-3 sm:p-6">
                        <h1 className="text-xl sm:text-3xl font-bold text-gray-900 mb-1 sm:mb-2">{business.name}</h1>
                        <div className="flex items-center text-xs sm:text-sm text-gray-500 mb-2 sm:mb-4">
                            <MapPin className="flex-shrink-0 mr-1 h-3 sm:h-5 w-3 sm:w-5 text-gray-400" />
                            <span className="line-clamp-1">{business.address}</span>
                        </div>
                        {/* Contact/Social Links */}
                        <div className="flex flex-wrap gap-2 sm:gap-4">
                            {business.instagram && (
                                <a href={`https://www.instagram.com/${business.instagram}`} target="_blank" rel="noopener noreferrer" className="flex items-center text-xs sm:text-sm text-gray-600 hover:text-purple-600">
                                    <Instagram className="h-3 sm:h-5 w-3 sm:w-5 mr-1 text-pink-500" /> Instagram
                                </a>
                            )}
                            {business.whatsapp && (
                                <a href={`https://wa.me/${business.whatsapp.replace(/\D/g, '')}`} target="_blank" rel="noopener noreferrer" className="flex items-center text-xs sm:text-sm text-gray-600 hover:text-green-600">
                                    <MessageCircle className="h-3 sm:h-5 w-3 sm:w-5 mr-1 text-green-500" /> WhatsApp
                                </a>
                            )}
                            {business.telephone && (
                                <a href={`tel:${business.telephone.replace(/\D/g, '')}`} className="flex items-center text-xs sm:text-sm text-gray-600 hover:text-blue-600">
                                    <Phone className="h-3 sm:h-5 w-3 sm:w-5 mr-1 text-blue-500" /> Telefone
                                </a>
                            )}
                            {business.coordinates && (
                                <a href={`https://www.google.com/maps/search/?api=1&query=${business.coordinates}`} target="_blank" rel="noopener noreferrer" className="flex items-center text-xs sm:text-sm text-gray-600 hover:text-yellow-600">
                                    <Map className="h-3 sm:h-5 w-3 sm:w-5 mr-1 text-yellow-500" /> Ver no Mapa
                                </a>
                            )}
                        </div>
                    </div>
                </div>

                {/* Employees Section as Filter */}
                {business.employees && business.employees.length > 0 && (
                    <div className="mb-4 sm:mb-6">
                        <div className="flex justify-between items-center mb-2 sm:mb-3">
                            <h2 className="text-base sm:text-xl font-bold text-gray-900">Profissionais</h2>
                            <button 
                                onClick={() => setShowEmployeeFilter(!showEmployeeFilter)}
                                className="flex items-center text-xs sm:text-sm text-purple-600 hover:text-purple-800"
                            >
                                <Filter className="h-3 sm:h-4 w-3 sm:w-4 mr-1" />
                                {selectedEmployeeId ? 'Alterar filtro' : 'Filtrar por profissional'}
                            </button>
                        </div>
                        
                        {/* Employee Filter Buttons/Dropdown */}
                        {showEmployeeFilter && (
                            <div className="bg-white rounded-lg shadow-md p-2 sm:p-3 mb-3 sm:mb-4">
                                <div className="flex flex-wrap gap-1.5 sm:gap-2">
                                    <button
                                        onClick={() => handleEmployeeSelect(null)}
                                        className={`px-2 sm:px-3 py-1 rounded-full text-xs font-medium ${
                                            selectedEmployeeId === null
                                                ? 'bg-purple-600 text-white'
                                                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                        }`}
                                    >
                                        Todos
                                    </button>
                                    {business.employees.map(employee => (
                                        <button
                                            key={employee.id}
                                            onClick={() => handleEmployeeSelect(employee.id)}
                                            className={`px-2 sm:px-3 py-1 rounded-full text-xs font-medium flex items-center ${
                                                selectedEmployeeId === employee.id
                                                    ? 'bg-purple-600 text-white'
                                                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                            }`}
                                        >
                                            <div className="w-3 h-3 sm:w-4 sm:h-4 rounded-full overflow-hidden mr-1 sm:mr-1.5 bg-gray-200 flex-shrink-0">
                                                {isValidImageSrc(employee.image) && (
                                                    <Image
                                                        src={employee.image}
                                                        alt=""
                                                        width={16}
                                                        height={16}
                                                        className="object-cover"
                                                        onError={(e) => { e.currentTarget.src = fallbackImage; }}
                                                    />
                                                )}
                                            </div>
                                            {employee.name}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                )}

                {/* Services Section */}
                <div>
                    <h2 className="text-base sm:text-xl font-bold text-gray-900 mb-3 sm:mb-6">Serviços</h2>
                    {filteredServices.length === 0 ? (
                        <div className="bg-white rounded-lg shadow-sm p-4 text-center">
                            <AlertCircle className="h-8 w-8 mx-auto text-yellow-500 mb-2" />
                            <p className="text-gray-600">
                                {selectedEmployeeId 
                                    ? "Este profissional não possui serviços disponíveis." 
                                    : "Nenhum serviço disponível no momento."}
                            </p>
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 gap-3 sm:gap-6 sm:grid-cols-2 lg:grid-cols-3">
                            {filteredServices.map(service => (
                                <div key={service.id} className="bg-white rounded-lg shadow-sm p-3 sm:p-6">
                                    <div className="flex items-start">
                                        <div className="h-14 sm:h-20 w-14 sm:w-20 relative bg-gray-100 rounded-md mr-2 sm:mr-4 flex-shrink-0">
                                            {isValidImageSrc(service.image) ? (
                                                <Image
                                                    src={service.image}
                                                    alt={service.name}
                                                    fill
                                                    sizes="(max-width: 640px) 56px, 80px"
                                                    className="object-cover rounded-md"
                                                    onError={(e) => { e.currentTarget.src = fallbackImage; }}
                                                />
                                            ) : (
                                                <div className="h-full w-full flex items-center justify-center bg-purple-100 rounded-md">
                                                    <CalendarIcon className="h-6 sm:h-8 w-6 sm:w-8 text-purple-500" />
                                                </div>
                                            )}
                                        </div>
                                        <div className="flex-grow">
                                            <h3 className="text-sm sm:text-base font-medium text-gray-900">{service.name}</h3>
                                            <div className="flex items-center text-xs sm:text-sm text-gray-500 mt-1 sm:mt-2">
                                                <Clock className="h-3 sm:h-4 w-3 sm:w-4 text-gray-400" />
                                                <span className="ml-1">{formatDuration(service.duration)}</span>
                                            </div>
                                            <div className="flex items-center text-xs sm:text-sm text-gray-500 mt-0.5 sm:mt-1">
                                                <DollarSign className="h-3 sm:h-4 w-3 sm:w-4 text-gray-400" />
                                                <span className="ml-1">
                                                    {service.price.toLocaleString('pt-BR', {
                                                        style: 'currency',
                                                        currency: 'BRL'
                                                    })}
                                                </span>
                                            </div>
                                            <button
                                                onClick={() => handleScheduleClick(service)}
                                                className="mt-2 sm:mt-3 w-full bg-purple-600 hover:bg-purple-700 text-white text-xs sm:text-sm font-medium py-1.5 sm:py-2 px-3 sm:px-4 rounded transition-colors"
                                            >
                                                Agendar
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Calendar Modal */}
                {showCalendar && selectedService && (
                    <AgendaModal
                        isOpen={showCalendar}
                        onClose={() => setShowCalendar(false)}
                        service={selectedService}
                        companyId={business.id}
                        employeeId={selectedEmployeeId}
                    />
                )}
            </div>

            {/* Floating Admin Button */}
            <FloatingAdministration companyId={business.id} />
        </div>
    );
}

export default BusinessPage;
