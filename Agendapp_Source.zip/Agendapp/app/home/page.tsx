'use client';

import React, { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import { Search, MapPin, Star, Loader2 } from 'lucide-react';
import Header from '../../components/Header/Header';
import Image from 'next/image';

// Define interfaces for API response data
interface Category {
  id: number;
  name: string;
  icon: string;
}

interface Company {
  id: number;
  name: string;
  code: string;
  address: string;
  categoryId: number;
  image: string | null;
  telephone: string;
  ispublic: number;
  cnpj: string | null;
  email: string | null;
  instagram: string | null;
  whatsapp: string | null;
  coordinates: string | null;
  category: Category; // Include category details
  // Add rating if available in your model or fetch separately
  rating?: number; // Optional rating, assuming it might not be directly in the Company model
}

// Helper function to validate image source
const isValidImageSrc = (src: string | null | undefined): src is string => {
  if (!src) return false;
  // Basic check for absolute URL or path starting with /
  return src.startsWith('http://') || src.startsWith('https://') || src.startsWith('/');
};

function Home() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Debounce search term input
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState(searchTerm);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 500); // 500ms delay

    // Cleanup function to cancel the timeout if searchTerm changes again quickly
    return () => {
      clearTimeout(handler);
    };
  }, [searchTerm]);

  const fetchBusinesses = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      let url = '/api/companies/search';
      const params = new URLSearchParams();
      if (selectedCategoryId) {
        params.append('categoryId', selectedCategoryId.toString());
      }
      if (debouncedSearchTerm) {
        params.append('searchTerm', debouncedSearchTerm);
      }
      const queryString = params.toString();
      if (queryString) {
        url += `?${queryString}`;
      }

      const response = await fetch(url);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      // Assuming API returns { companies: [], categories: [] }
      setCompanies(data.companies || []);
      // Only set categories once on initial load, or if they are dynamic based on search
      if (categories.length === 0 && data.categories) {
          setCategories(data.categories);
      }
    } catch (e: any) {
      console.error("Failed to fetch businesses:", e);
      setError(`Falha ao carregar estabelecimentos: ${e.message}`);
      setCompanies([]); // Clear companies on error
    } finally {
      setIsLoading(false);
    }
  }, [selectedCategoryId, debouncedSearchTerm, categories.length]); // Depend on debounced term

  useEffect(() => {
    fetchBusinesses();
  }, [fetchBusinesses]); // Fetch whenever filters change

  const fallbackImage = '/img/logo.png';

  return (
    <div className="min-h-screen bg-gray-50 pt-16 md:pt-20"> {/* Ajustado pt para mobile */}
      <Header />
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-8">
        {/* Search and Filter Section */}
        <div className="mb-4 sm:mb-8 space-y-3 sm:space-y-4">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 sm:h-5 sm:w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-9 sm:pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-purple-500 focus:border-purple-500 text-sm"
              placeholder="Buscar estabelecimentos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="flex space-x-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100 -mx-3 px-3">
            <button
              onClick={() => setSelectedCategoryId(null)}
              className={`flex-shrink-0 px-3 sm:px-4 py-1.5 sm:py-2 rounded-full text-xs sm:text-sm font-medium whitespace-nowrap ${
                selectedCategoryId === null
                  ? 'bg-purple-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-300'
              }`}
            >
              Todos
            </button>
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategoryId(category.id)}
                className={`flex-shrink-0 px-3 sm:px-4 py-1.5 sm:py-2 rounded-full text-xs sm:text-sm font-medium whitespace-nowrap ${
                  selectedCategoryId === category.id
                    ? 'bg-purple-600 text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-300'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>

        {/* Business List */}
        {isLoading ? (
          <div className="flex justify-center items-center py-6 sm:py-10">
            <Loader2 className="h-6 w-6 sm:h-8 sm:w-8 animate-spin text-purple-600" />
            <p className="ml-2 text-sm sm:text-base text-gray-600">Carregando estabelecimentos...</p>
          </div>
        ) : error ? (
          <div className="text-center py-6 sm:py-10 text-red-600 bg-red-50 p-3 sm:p-4 rounded-md">
            <p className="text-sm sm:text-base">{error}</p>
            <button
              onClick={fetchBusinesses} // Allow retry
              className="mt-3 sm:mt-4 px-3 sm:px-4 py-1.5 sm:py-2 bg-purple-600 text-white text-sm rounded hover:bg-purple-700"
            >
              Tentar Novamente
            </button>
          </div>
        ) : companies.length === 0 ? (
           <div className="text-center py-6 sm:py-10 text-gray-500">
            <p className="text-sm sm:text-base">Nenhum estabelecimento encontrado com os filtros selecionados.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 xs:grid-cols-2 gap-3 sm:gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            {companies.map((business) => (
              <Link
                key={business.id}
                href={`/business/${business.code}`} // Updated href to use /business/ prefix
                className="block bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow overflow-hidden group"
              >
                <div className="h-28 sm:h-32 w-full relative bg-gray-100">
                  <Image
                    src={isValidImageSrc(business.image) ? business.image : fallbackImage}
                    alt={business.name}
                    fill
                    sizes="(max-width: 480px) 100vw, (max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                    onError={(e) => { e.currentTarget.src = fallbackImage; }} // Fallback on error
                  />
                </div>
                <div className="p-2.5 sm:p-4">
                  <h3 className="text-sm font-medium text-gray-900 truncate">{business.name}</h3>
                  <p className="mt-1 text-xs text-gray-500 truncate">{business.category.name}</p>
                  <div className="mt-1.5 sm:mt-2 flex items-center text-xs text-gray-500 truncate">
                    <MapPin className="flex-shrink-0 mr-1 h-3 w-3 text-gray-400" />
                    {business.address}
                  </div>
                  {/* Display rating if available */}
                  {business.rating && (
                    <div className="mt-1.5 sm:mt-2 flex items-center">
                      <Star className="text-yellow-400 h-3 w-3" />
                      <span className="ml-1 text-xs text-gray-600">{business.rating.toFixed(1)}</span>
                    </div>
                  )}
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default Home;
