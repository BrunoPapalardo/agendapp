"use client";

import { signIn } from "next-auth/react";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import { Eye, EyeOff, Loader2, LogIn } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const router = useRouter();
  const { status } = useSession();

  useEffect(() => {
    // Redirect if already authenticated
    if (status === "authenticated") {
      router.push("/home");
    }
  }, [status, router]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage("");

    try {
      const result = await signIn("credentials", { 
        email, 
        password, 
        redirect: false // Handle redirect manually based on result
      });

      if (!result?.ok) {
        // Handle specific errors if provided by NextAuth, otherwise show generic message
        setErrorMessage(result?.error || "E-mail ou senha inválidos!");
      } else {
        // Redirect on successful login
        router.push("/home");
      }
    } catch (error) {
      console.error("Login error:", error);
      setErrorMessage("Ocorreu um erro durante o login. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  // Show loading state while session status is being determined
  if (status === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
      </div>
    );
  }
  
  // Don't render login form if already authenticated (avoids flash of content)
  if (status === "authenticated") {
      return null;
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-purple-50 via-white to-green-50 p-4">
      {/* Logo */}
      <div className="mb-6 flex items-center gap-2">
        <Image
          src="/img/logo.png" // Corrected escaped quotes
          alt="Agenday Logo" // Corrected escaped quotes
          width={40}
          height={40}
          className="object-contain"
        />
        <span className="text-2xl font-bold text-gray-900">Agenday</span>
      </div>

      <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg max-w-md w-full">
        <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 text-center">Faça login</h2>
        <p className="text-gray-600 text-center mt-1 sm:mt-2 text-sm sm:text-base">Entre com suas credenciais</p>

        {errorMessage && (
          <div className="mt-4 p-3 bg-red-50 text-red-700 text-sm rounded-lg text-center">
            {errorMessage}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">E-mail</label>
            <input
              type="email"
              placeholder="Digite seu e-mail"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="block w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-purple-500 focus:border-purple-500 text-sm sm:text-base"
              aria-label="Endereço de e-mail"
            />
          </div>

          <div className="relative">
            <label className="block text-sm font-medium text-gray-700 mb-1">Senha</label>
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Digite sua senha"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="block w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-purple-500 focus:border-purple-500 pr-10 text-sm sm:text-base"
              aria-label="Senha"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-9 sm:top-10 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 p-1 rounded-full hover:bg-gray-100"
              aria-label={showPassword ? "Esconder senha" : "Mostrar senha"}
            >
              {/* Corrected responsive icon size syntax */}
              {showPassword ? <EyeOff className="h-4 w-4 sm:h-5 sm:w-5" /> : <Eye className="h-4 w-4 sm:h-5 sm:w-5" />}
            </button>
          </div>

          <button
            type="submit"
            className={`w-full flex justify-center items-center px-4 py-3 text-white font-bold rounded-lg transition duration-200 ease-in-out ${
              loading 
                ? "bg-purple-400 cursor-not-allowed" 
                : "bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500"
            }`}
            disabled={loading}
          >
            {loading ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <>
                <LogIn size={18} className="mr-2"/>
                Entrar
              </>
            )}
          </button>
        </form>

        <p className="mt-6 text-sm text-gray-600 text-center">
          Ainda não tem uma conta?{" "}
          <Link href="/register" className="font-medium text-purple-600 hover:underline">
            Cadastre-se
          </Link>
        </p>
      </div>
    </div>
  );
}

