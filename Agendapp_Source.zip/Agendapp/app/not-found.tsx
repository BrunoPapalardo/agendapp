import ErrorPage from "@/components/ErrorPage/ErrorPage";

export default function NotFound() {
    return <ErrorPage message="Página não encontrada" />;
}
