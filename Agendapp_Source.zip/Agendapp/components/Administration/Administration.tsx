'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { ShieldEllipsis, User, Clock, CalendarDays, Settings, Plus, Trash, Edit, Save, X } from 'lucide-react';
import BusinessHoursConfig from '@/components/BusinessHours/BusinessHours';
import AgendaModal from '@/components/Calendar/Calendar';
import Image from 'next/image';

interface Service {
  id: number;
  name: string;
  price: number;
  duration: number;
  prepareTime: number;
  intervalTime: number;
  image: string | null;
}

interface Employee {
  id: number;
  name: string;
  image: string;
}

interface CompanyAdminProps {
  companyId: number;
  companyCode: string;
}

const FloatingAdministration = ({ companyId, companyCode }: CompanyAdminProps) => {
  const { data: session } = useSession();
  const [isOpen, setIsOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [activeTab, setActiveTab] = useState<'agenda' | 'horarios' | 'servicos' | 'funcionarios' | 'configuracoes'>('agenda');
  const [showBusinessHour, setShowBusinessHour] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [companyStatus, setCompanyStatus] = useState<number>(1); // 1 = público, 0 = privado
  const [services, setServices] = useState<Service[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Estados para edição de serviço
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [newService, setNewService] = useState<Partial<Service>>({
    name: '',
    price: 0,
    duration: 30,
    prepareTime: 0,
    intervalTime: 0
  });

  // Estados para edição de funcionário
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [newEmployee, setNewEmployee] = useState<Partial<Employee>>({
    name: '',
    image: ''
  });

  // Verificar se o usuário é administrador da empresa
  useEffect(() => {
    if (session?.user?.companyRoles) {
      const isCompanyAdmin = session.user.companyRoles.some(
        role => role.companyId === companyId && role.role === 'admin'
      );
      setIsAdmin(isCompanyAdmin);
    }
  }, [session, companyId]);

  // Carregar dados da empresa
  useEffect(() => {
    if (companyId && isAdmin) {
      fetchCompanyData();
    }
  }, [companyId, isAdmin]);

  const fetchCompanyData = async () => {
    setLoading(true);
    setError(null);
    try {
      // Buscar dados da empresa
      const companyResponse = await fetch(`/api/companies/${companyCode}`);
      if (!companyResponse.ok) throw new Error('Falha ao carregar dados da empresa');
      const companyData = await companyResponse.json();
      
      setCompanyStatus(companyData.ispublic);
      setServices(companyData.services || []);
      setEmployees(companyData.employees || []);
    } catch (err: any) {
      console.error('Erro ao carregar dados:', err);
      setError(err.message || 'Erro ao carregar dados');
    } finally {
      setLoading(false);
    }
  };

  const toggleCompanyStatus = async () => {
    try {
      const newStatus = companyStatus === 1 ? 0 : 1;
      const response = await fetch(`/api/companies/update`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          companyId, 
          data: { ispublic: newStatus } 
        }),
      });
      
      if (!response.ok) throw new Error('Falha ao atualizar status');
      
      setCompanyStatus(newStatus);
    } catch (err: any) {
      console.error('Erro ao atualizar status:', err);
      setError(err.message || 'Erro ao atualizar status');
    }
  };

  // Funções para gerenciar serviços
  const handleAddService = async () => {
    try {
      if (!newService.name || !newService.price || !newService.duration) {
        setError('Preencha todos os campos obrigatórios');
        return;
      }
      
      const response = await fetch('/api/services/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...newService,
          companyId
        }),
      });
      
      if (!response.ok) throw new Error('Falha ao adicionar serviço');
      
      const createdService = await response.json();
      setServices([...services, createdService]);
      setNewService({
        name: '',
        price: 0,
        duration: 30,
        prepareTime: 0,
        intervalTime: 0
      });
    } catch (err: any) {
      console.error('Erro ao adicionar serviço:', err);
      setError(err.message || 'Erro ao adicionar serviço');
    }
  };

  const handleUpdateService = async () => {
    if (!editingService) return;
    
    try {
      const response = await fetch(`/api/services/update`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: editingService.id,
          ...newService
        }),
      });
      
      if (!response.ok) throw new Error('Falha ao atualizar serviço');
      
      const updatedService = await response.json();
      setServices(services.map(s => s.id === updatedService.id ? updatedService : s));
      setEditingService(null);
    } catch (err: any) {
      console.error('Erro ao atualizar serviço:', err);
      setError(err.message || 'Erro ao atualizar serviço');
    }
  };

  const handleDeleteService = async (serviceId: number) => {
    try {
      const response = await fetch(`/api/services/delete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: serviceId }),
      });
      
      if (!response.ok) throw new Error('Falha ao excluir serviço');
      
      setServices(services.filter(s => s.id !== serviceId));
    } catch (err: any) {
      console.error('Erro ao excluir serviço:', err);
      setError(err.message || 'Erro ao excluir serviço');
    }
  };

  // Funções para gerenciar funcionários
  const handleAddEmployee = async () => {
    try {
      if (!newEmployee.name) {
        setError('Nome do funcionário é obrigatório');
        return;
      }
      
      const response = await fetch('/api/employees/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...newEmployee,
          companyId
        }),
      });
      
      if (!response.ok) throw new Error('Falha ao adicionar funcionário');
      
      const createdEmployee = await response.json();
      setEmployees([...employees, createdEmployee]);
      setNewEmployee({
        name: '',
        image: ''
      });
    } catch (err: any) {
      console.error('Erro ao adicionar funcionário:', err);
      setError(err.message || 'Erro ao adicionar funcionário');
    }
  };

  // Se o usuário não for administrador, não mostrar o componente
  if (!isAdmin) return null;

  return (
    <>
      <div className="fixed bottom-8 right-8 flex flex-col items-end space-y-2 z-40">
        {isOpen && (
          <div className="bg-white shadow-lg rounded-lg p-4 w-72 md:w-96">
            {/* Tabs de navegação */}
            <div className="flex overflow-x-auto mb-4 pb-2 border-b">
              <button
                className={`px-3 py-2 text-sm font-medium rounded-t-lg ${
                  activeTab === 'agenda' ? 'bg-purple-100 text-purple-700' : 'text-gray-600 hover:text-purple-600'
                }`}
                onClick={() => setActiveTab('agenda')}
              >
                Agenda
              </button>
              <button
                className={`px-3 py-2 text-sm font-medium rounded-t-lg ${
                  activeTab === 'horarios' ? 'bg-purple-100 text-purple-700' : 'text-gray-600 hover:text-purple-600'
                }`}
                onClick={() => setActiveTab('horarios')}
              >
                Horários
              </button>
              <button
                className={`px-3 py-2 text-sm font-medium rounded-t-lg ${
                  activeTab === 'servicos' ? 'bg-purple-100 text-purple-700' : 'text-gray-600 hover:text-purple-600'
                }`}
                onClick={() => setActiveTab('servicos')}
              >
                Serviços
              </button>
              <button
                className={`px-3 py-2 text-sm font-medium rounded-t-lg ${
                  activeTab === 'funcionarios' ? 'bg-purple-100 text-purple-700' : 'text-gray-600 hover:text-purple-600'
                }`}
                onClick={() => setActiveTab('funcionarios')}
              >
                Funcionários
              </button>
              <button
                className={`px-3 py-2 text-sm font-medium rounded-t-lg ${
                  activeTab === 'configuracoes' ? 'bg-purple-100 text-purple-700' : 'text-gray-600 hover:text-purple-600'
                }`}
                onClick={() => setActiveTab('configuracoes')}
              >
                Config
              </button>
            </div>

            {/* Conteúdo da tab ativa */}
            <div className="p-2">
              {activeTab === 'agenda' && (
                <div>
                  <h3 className="text-lg font-semibold mb-3">Agenda</h3>
                  <button
                    className="w-full bg-purple-600 text-white py-2 px-4 rounded hover:bg-purple-700 transition"
                    onClick={() => setShowCalendar(true)}
                  >
                    Ver Agenda Completa
                  </button>
                </div>
              )}

              {activeTab === 'horarios' && (
                <div>
                  <h3 className="text-lg font-semibold mb-3">Horários de Funcionamento</h3>
                  <button
                    className="w-full bg-purple-600 text-white py-2 px-4 rounded hover:bg-purple-700 transition"
                    onClick={() => setShowBusinessHour(true)}
                  >
                    Configurar Horários
                  </button>
                </div>
              )}

              {activeTab === 'servicos' && (
                <div>
                  <h3 className="text-lg font-semibold mb-3">Serviços</h3>
                  
                  {error && <p className="text-red-500 text-sm mb-2">{error}</p>}
                  
                  {/* Lista de serviços */}
                  <div className="max-h-60 overflow-y-auto mb-4">
                    {services.length === 0 ? (
                      <p className="text-gray-500 text-sm">Nenhum serviço cadastrado</p>
                    ) : (
                      <ul className="space-y-2">
                        {services.map(service => (
                          <li key={service.id} className="border rounded p-2 flex justify-between items-center">
                            <div>
                              <p className="font-medium">{service.name}</p>
                              <p className="text-sm text-gray-600">R$ {service.price.toFixed(2)} • {service.duration} min</p>
                            </div>
                            <div className="flex space-x-1">
                              <button 
                                onClick={() => {
                                  setEditingService(service);
                                  setNewService({
                                    name: service.name,
                                    price: service.price,
                                    duration: service.duration,
                                    prepareTime: service.prepareTime,
                                    intervalTime: service.intervalTime
                                  });
                                }}
                                className="p-1 text-blue-600 hover:bg-blue-100 rounded"
                              >
                                <Edit size={16} />
                              </button>
                              <button 
                                onClick={() => handleDeleteService(service.id)}
                                className="p-1 text-red-600 hover:bg-red-100 rounded"
                              >
                                <Trash size={16} />
                              </button>
                            </div>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                  
                  {/* Formulário de edição/adição */}
                  <div className="border rounded p-3 bg-gray-50">
                    <h4 className="font-medium mb-2">
                      {editingService ? 'Editar Serviço' : 'Adicionar Serviço'}
                    </h4>
                    <div className="space-y-2">
                      <input
                        type="text"
                        placeholder="Nome do serviço"
                        value={newService.name || ''}
                        onChange={(e) => setNewService({...newService, name: e.target.value})}
                        className="w-full p-2 border rounded"
                      />
                      <div className="flex space-x-2">
                        <input
                          type="number"
                          placeholder="Preço (R$)"
                          value={newService.price || ''}
                          onChange={(e) => setNewService({...newService, price: parseFloat(e.target.value)})}
                          className="w-1/2 p-2 border rounded"
                        />
                        <input
                          type="number"
                          placeholder="Duração (min)"
                          value={newService.duration || ''}
                          onChange={(e) => setNewService({...newService, duration: parseInt(e.target.value)})}
                          className="w-1/2 p-2 border rounded"
                        />
                      </div>
                      <div className="flex space-x-2">
                        <input
                          type="number"
                          placeholder="Preparo (min)"
                          value={newService.prepareTime || ''}
                          onChange={(e) => setNewService({...newService, prepareTime: parseInt(e.target.value)})}
                          className="w-1/2 p-2 border rounded"
                        />
                        <input
                          type="number"
                          placeholder="Intervalo (min)"
                          value={newService.intervalTime || ''}
                          onChange={(e) => setNewService({...newService, intervalTime: parseInt(e.target.value)})}
                          className="w-1/2 p-2 border rounded"
                        />
                      </div>
                      <div className="flex justify-end space-x-2">
                        {editingService && (
                          <button
                            onClick={() => {
                              setEditingService(null);
                              setNewService({
                                name: '',
                                price: 0,
                                duration: 30,
                                prepareTime: 0,
                                intervalTime: 0
                              });
                            }}
                            className="px-3 py-1 text-gray-600 bg-gray-200 rounded hover:bg-gray-300"
                          >
                            Cancelar
                          </button>
                        )}
                        <button
                          onClick={editingService ? handleUpdateService : handleAddService}
                          className="px-3 py-1 text-white bg-purple-600 rounded hover:bg-purple-700"
                        >
                          {editingService ? 'Salvar' : 'Adicionar'}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'funcionarios' && (
                <div>
                  <h3 className="text-lg font-semibold mb-3">Funcionários</h3>
                  
                  {/* Lista de funcionários */}
                  <div className="max-h-60 overflow-y-auto mb-4">
                    {employees.length === 0 ? (
                      <p className="text-gray-500 text-sm">Nenhum funcionário cadastrado</p>
                    ) : (
                      <ul className="space-y-2">
                        {employees.map(employee => (
                          <li key={employee.id} className="border rounded p-2 flex items-center">
                            <div className="w-10 h-10 rounded-full overflow-hidden mr-3 bg-gray-200">
                              {employee.image && (
                                <Image
                                  src={employee.image}
                                  alt={employee.name}
                                  width={40}
                                  height={40}
                                  className="w-full h-full object-cover"
                                />
                              )}
                            </div>
                            <div className="flex-grow">
                              <p className="font-medium">{employee.name}</p>
                            </div>
                            <div className="flex space-x-1">
                              <button className="p-1 text-blue-600 hover:bg-blue-100 rounded">
                                <Edit size={16} />
                              </button>
                            </div>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                  
                  {/* Formulário para adicionar funcionário */}
                  <div className="border rounded p-3 bg-gray-50">
                    <h4 className="font-medium mb-2">Adicionar Funcionário</h4>
                    <div className="space-y-2">
                      <input
                        type="text"
                        placeholder="Nome do funcionário"
                        value={newEmployee.name || ''}
                        onChange={(e) => setNewEmployee({...newEmployee, name: e.target.value})}
                        className="w-full p-2 border rounded"
                      />
                      <input
                        type="text"
                        placeholder="URL da imagem (opcional)"
                        value={newEmployee.image || ''}
                        onChange={(e) => setNewEmployee({...newEmployee, image: e.target.value})}
                        className="w-full p-2 border rounded"
                      />
                      <div className="flex justify-end">
                        <button
                          onClick={handleAddEmployee}
                          className="px-3 py-1 text-white bg-purple-600 rounded hover:bg-purple-700"
                        >
                          Adicionar
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'configuracoes' && (
                <div>
                  <h3 className="text-lg font-semibold mb-3">Configurações</h3>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between items-center p-3 border rounded">
                      <span className="font-medium">Status da Empresa:</span>
                      <button
                        onClick={toggleCompanyStatus}
                        className={`px-3 py-1 rounded-full text-white ${
                          companyStatus === 1 ? 'bg-green-500' : 'bg-red-500'
                        }`}
                      >
                        {companyStatus === 1 ? 'Público' : 'Privado'}
                      </button>
                    </div>
                    
                    <p className="text-sm text-gray-600">
                      Quando definido como "Privado", sua empresa não aparecerá nas buscas públicas.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
        
        {/* Botão de administração */}
        <button
          className="bg-purple-600 text-white p-4 rounded-full shadow-lg hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-400 transition-all"
          onClick={() => setIsOpen(!isOpen)}
          aria-label="Administração"
        >
          <ShieldEllipsis size={20} />
        </button>
      </div>

      {/* Modais */}
      {showBusinessHour && (
        <BusinessHoursConfig
          companyId={companyId}
          setShowBusinessHour={setShowBusinessHour}
        />
      )}

      {showCalendar && (
        <AgendaModal 
          showCalendar={showCalendar} 
          setShowCalendar={setShowCalendar}
          companyId={companyId}
          service={null}
          employees={employees}
          businessHours={[]}
        />
      )}
    </>
  );
};

export default FloatingAdministration;
