import { useEffect, useState } from "react";
import { Trash2, Plus, AlertCircle, Check, Clock } from "lucide-react";

type BusinessHour = {
  id?: number;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
};

const days = [
  "Domingo",
  "Segunda-feira",
  "Terça-feira",
  "Quarta-feira",
  "Quinta-feira",
  "Sexta-feira",
  "Sábado"
];

// Função para validar horários
const isValidTimeRange = (start: string, end: string): boolean => {
  if (!start || !end) return false;
  
  const startTime = new Date(`1970-01-01T${start}`);
  const endTime = new Date(`1970-01-01T${end}`);
  
  return startTime < endTime;
};

// Função para verificar sobreposição entre dois intervalos de tempo
const isOverlapping = (
  start1: string, 
  end1: string, 
  start2: string, 
  end2: string
): boolean => {
  const s1 = new Date(`1970-01-01T${start1}`);
  const e1 = new Date(`1970-01-01T${end1}`);
  const s2 = new Date(`1970-01-01T${start2}`);
  const e2 = new Date(`1970-01-01T${end2}`);
  
  return (s1 < e2 && e1 > s2);
};

// Função para formatar horário em formato amigável
const formatTimeRange = (start: string, end: string): string => {
  if (!start || !end) return "";
  
  // Remover os segundos se existirem
  const formatTime = (time: string) => {
    const parts = time.split(':');
    return parts.length >= 2 ? `${parts[0]}:${parts[1]}` : time;
  };
  
  return `${formatTime(start)} - ${formatTime(end)}`;
};

export default function BusinessHoursConfig({
  companyId,
  setShowBusinessHour,
}: {
  companyId: number;
  setShowBusinessHour: React.Dispatch<React.SetStateAction<boolean>>;
}) {
  const [hours, setHours] = useState<Record<number, BusinessHour[]>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [activeDay, setActiveDay] = useState<number | null>(null);

  // Carregar horários existentes
  useEffect(() => {
    if (!companyId) return;
    
    setLoading(true);
    setError(null);
    
    fetch(`/api/business-hours?companyId=${companyId}`)
      .then((res) => {
        if (!res.ok) {
          throw new Error(`Erro ao carregar horários: ${res.status}`);
        }
        return res.json();
      })
      .then((data) => {
        const grouped: Record<number, BusinessHour[]> = {};
        // Inicializar todos os dias da semana com arrays vazios
        for (let i = 0; i < 7; i++) {
          grouped[i] = [];
        }
        // Preencher com os dados recebidos
        data.forEach((h: BusinessHour) => {
          grouped[h.dayOfWeek].push(h);
        });
        setHours(grouped);
      })
      .catch((err) => {
        console.error("Erro ao carregar horários:", err);
        setError("Não foi possível carregar os horários. Tente novamente.");
      })
      .finally(() => {
        setLoading(false);
      });
  }, [companyId]);

  // Adicionar novo horário para um dia específico
  const addHour = (dayOfWeek: number) => {
    // Definir horários padrão com base no último horário configurado para este dia
    let startTime = "08:00";
    let endTime = "18:00";
    
    const existingHours = hours[dayOfWeek] || [];
    if (existingHours.length > 0) {
      // Sugerir um horário após o último configurado
      const lastHour = existingHours[existingHours.length - 1];
      startTime = lastHour.endTime;
      
      // Calcular um horário de término 2 horas após o início
      const startDate = new Date(`1970-01-01T${startTime}`);
      startDate.setHours(startDate.getHours() + 2);
      endTime = `${String(startDate.getHours()).padStart(2, '0')}:${String(startDate.getMinutes()).padStart(2, '0')}`;
    }
    
    const newHour = { dayOfWeek, startTime, endTime };
    setHours({ ...hours, [dayOfWeek]: [...(hours[dayOfWeek] || []), newHour] });
    
    // Validar o novo horário imediatamente
    validateHourEntry(dayOfWeek, existingHours.length, newHour);
    
    // Limpar mensagens
    setSuccess(null);
    setError(null);
    
    // Expandir o dia automaticamente
    setActiveDay(dayOfWeek);
  };

  // Remover um horário
  const removeHour = (dayOfWeek: number, index: number) => {
    const newHours = [...(hours[dayOfWeek] || [])];
    newHours.splice(index, 1);
    setHours({ ...hours, [dayOfWeek]: newHours });
    
    // Remover erros de validação associados
    const newValidationErrors = { ...validationErrors };
    delete newValidationErrors[`${dayOfWeek}-${index}`];
    
    // Revalidar os horários restantes para este dia
    newHours.forEach((hour, idx) => {
      validateHourEntry(dayOfWeek, idx, hour, newHours);
    });
    
    setValidationErrors(newValidationErrors);
    
    // Limpar mensagens
    setSuccess(null);
    setError(null);
  };

  // Validar um horário específico
  const validateHourEntry = (
    dayOfWeek: number, 
    index: number, 
    hour: BusinessHour,
    dayHours?: BusinessHour[]
  ): boolean => {
    const key = `${dayOfWeek}-${index}`;
    const newValidationErrors = { ...validationErrors };
    const hoursToCheck = dayHours || hours[dayOfWeek] || [];
    
    // Verificar se o horário de início é anterior ao horário de término
    if (!isValidTimeRange(hour.startTime, hour.endTime)) {
      newValidationErrors[key] = "O horário de término deve ser posterior ao horário de início";
      setValidationErrors(newValidationErrors);
      return false;
    }
    
    // Verificar sobreposição de horários no mesmo dia
    for (let i = 0; i < hoursToCheck.length; i++) {
      if (i !== index) {
        const otherHour = hoursToCheck[i];
        
        // Verificar sobreposição
        if (isOverlapping(
          hour.startTime, 
          hour.endTime, 
          otherHour.startTime, 
          otherHour.endTime
        )) {
          newValidationErrors[key] = "Este horário se sobrepõe a outro período configurado";
          setValidationErrors(newValidationErrors);
          return false;
        }
      }
    }
    
    // Se chegou aqui, o horário é válido
    delete newValidationErrors[key];
    setValidationErrors(newValidationErrors);
    return true;
  };

  // Validar todos os horários
  const validateAllHours = (): boolean => {
    let isValid = true;
    
    // Verificar cada horário
    Object.entries(hours).forEach(([dayOfWeek, dayHours]) => {
      dayHours.forEach((hour, index) => {
        if (!validateHourEntry(parseInt(dayOfWeek), index, hour, dayHours)) {
          isValid = false;
        }
      });
    });
    
    return isValid;
  };

  // Salvar todos os horários
  const saveHours = async () => {
    // Validar horários antes de salvar
    if (!validateAllHours()) {
      setError("Existem horários inválidos ou sobrepostos. Por favor, corrija-os antes de salvar.");
      return;
    }
    
    setLoading(true);
    setError(null);
    setSuccess(null);
    
    const hoursData = Object.values(hours).flat();
    
    try {
      const response = await fetch(`/api/business-hours`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ companyId, horarios: hoursData }),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Erro ao salvar horários");
      }
      
      setSuccess("Horários salvos com sucesso!");
      
      // Fechar o modal após 1.5 segundos
      setTimeout(() => {
        setShowBusinessHour(false);
      }, 1500);
    } catch (err: any) {
      console.error("Erro ao salvar horários:", err);
      setError(err.message || "Erro ao salvar horários. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  // Atualizar um horário específico
  const updateHourTime = (dayOfWeek: number, index: number, field: 'startTime' | 'endTime', value: string) => {
    const updatedHours = {
      ...hours,
      [dayOfWeek]: hours[dayOfWeek].map((item, i) =>
        i === index ? { ...item, [field]: value } : item
      ),
    };
    
    setHours(updatedHours);
    
    // Validar o horário atualizado
    const updatedHour = updatedHours[dayOfWeek][index];
    validateHourEntry(dayOfWeek, index, updatedHour, updatedHours[dayOfWeek]);
    
    // Limpar mensagens
    setSuccess(null);
    setError(null);
  };

  // Alternar a exibição de um dia
  const toggleDay = (dayIndex: number) => {
    setActiveDay(activeDay === dayIndex ? null : dayIndex);
  };

  // Verificar se um dia tem horários configurados
  const hasDayHours = (dayIndex: number): boolean => {
    return hours[dayIndex] && hours[dayIndex].length > 0;
  };

  // Verificar se um dia tem erros de validação
  const hasDayErrors = (dayIndex: number): boolean => {
    return Object.keys(validationErrors).some(key => key.startsWith(`${dayIndex}-`));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center p-2 sm:p-4 z-50">
      <div className="w-full max-w-md bg-white text-gray-900 rounded-lg shadow max-h-[90vh] flex flex-col">
        <div className="p-3 sm:p-4 border-b">
          <h1 className="text-lg sm:text-xl font-bold text-purple-600">Horário Comercial</h1>
          <p className="text-xs sm:text-sm text-gray-500">Configure os horários de funcionamento</p>
        </div>

        {/* Mensagens de erro ou sucesso */}
        {error && (
          <div className="mx-3 sm:mx-4 mt-2 p-2 bg-red-50 text-red-700 text-xs sm:text-sm rounded flex items-center">
            <AlertCircle className="h-4 w-4 mr-2 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}
        
        {success && (
          <div className="mx-3 sm:mx-4 mt-2 p-2 bg-green-50 text-green-700 text-xs sm:text-sm rounded flex items-center">
            <Check className="h-4 w-4 mr-2 flex-shrink-0" />
            <span>{success}</span>
          </div>
        )}

        {/* Container para o conteúdo rolável */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4">
          {loading && !Object.keys(hours).length ? (
            <div className="text-center py-4 text-gray-500 text-sm">Carregando horários...</div>
          ) : (
            <div className="space-y-3 sm:space-y-4">
              {days.map((day, dayIndex) => (
                <div 
                  key={dayIndex} 
                  className={`border rounded-lg overflow-hidden ${
                    hasDayErrors(dayIndex) ? 'border-red-300' : 'border-gray-200'
                  }`}
                >
                  {/* Cabeçalho do dia com toggle */}
                  <div 
                    className={`flex justify-between items-center p-3 cursor-pointer ${
                      activeDay === dayIndex ? 'bg-purple-50' : 'bg-gray-50'
                    } ${hasDayErrors(dayIndex) ? 'bg-red-50' : ''}`}
                    onClick={() => toggleDay(dayIndex)}
                  >
                    <div className="flex items-center">
                      <span className={`font-medium text-sm ${hasDayErrors(dayIndex) ? 'text-red-600' : ''}`}>
                        {day}
                      </span>
                      {hasDayErrors(dayIndex) && (
                        <AlertCircle className="h-4 w-4 text-red-500 ml-2" />
                      )}
                    </div>
                    
                    <div className="flex items-center">
                      {!hasDayHours(dayIndex) ? (
                        <span className="text-xs text-gray-400 mr-2">Folga</span>
                      ) : (
                        <span className="text-xs text-gray-600 mr-2 flex items-center">
                          <Clock className="h-3 w-3 mr-1" />
                          {hours[dayIndex].length} {hours[dayIndex].length === 1 ? 'período' : 'períodos'}
                        </span>
                      )}
                      
                      <button
                        className="text-xs text-purple-600 hover:text-purple-800 flex items-center gap-1 ml-2"
                        onClick={(e) => {
                          e.stopPropagation();
                          addHour(dayIndex);
                        }}
                        disabled={loading}
                      >
                        <Plus size={14} />
                        <span className="hidden sm:inline">Adicionar</span>
                      </button>
                    </div>
                  </div>

                  {/* Conteúdo expandido do dia */}
                  {activeDay === dayIndex && (
                    <div className="p-3 space-y-3 bg-white">
                      {hours[dayIndex]?.map((h, index) => {
                        const errorKey = `${dayIndex}-${index}`;
                        const errorMessage = validationErrors[errorKey];
                        
                        return (
                          <div key={index} className="relative">
                            <div className="flex items-center gap-2">
                              <div className="flex-1">
                                <label className="text-xs text-gray-500 block">Início</label>
                                <input
                                  type="time"
                                  className={`w-full bg-gray-50 p-2 rounded text-gray-900 border text-sm ${
                                    errorMessage ? 'border-red-500' : 'border-gray-200'
                                  }`}
                                  value={h.startTime}
                                  onChange={(e) => updateHourTime(dayIndex, index, 'startTime', e.target.value)}
                                  disabled={loading}
                                />
                              </div>
                              <div className="flex-1">
                                <label className="text-xs text-gray-500 block">Fim</label>
                                <input
                                  type="time"
                                  className={`w-full bg-gray-50 p-2 rounded text-gray-900 border text-sm ${
                                    errorMessage ? 'border-red-500' : 'border-gray-200'
                                  }`}
                                  value={h.endTime}
                                  onChange={(e) => updateHourTime(dayIndex, index, 'endTime', e.target.value)}
                                  disabled={loading}
                                />
                              </div>
                              <button
                                className="text-red-500 hover:text-red-700 mt-5"
                                onClick={() => removeHour(dayIndex, index)}
                                disabled={loading}
                                aria-label="Remover horário"
                              >
                                <Trash2 size={18} />
                              </button>
                            </div>
                            {errorMessage && (
                              <p className="text-xs text-red-500 mt-1">
                                {errorMessage}
                              </p>
                            )}
                          </div>
                        );
                      })}
                      
                      {!hours[dayIndex]?.length && (
                        <p className="text-xs text-gray-500 italic">
                          Nenhum horário configurado para este dia. Clique em "Adicionar" para configurar.
                        </p>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Botões fixos na parte inferior */}
        <div className="p-3 sm:p-4 border-t flex justify-between gap-3 sm:gap-4">
          <button
            className="flex-1 bg-gray-200 text-gray-800 px-3 sm:px-4 py-2 rounded text-sm hover:bg-gray-300 focus:outline-none transition-colors"
            onClick={() => setShowBusinessHour(false)}
            disabled={loading}
          >
            Cancelar
          </button>
          <button
            className={`flex-1 px-3 sm:px-4 py-2 rounded text-sm focus:outline-none transition-colors ${
              loading 
                ? 'bg-purple-400 text-white cursor-not-allowed' 
                : 'bg-purple-600 text-white hover:bg-purple-700'
            }`}
            onClick={saveHours}
            disabled={loading}
          >
            {loading ? 'Salvando...' : 'Salvar Horários'}
          </button>
        </div>
      </div>
    </div>
  );
}
