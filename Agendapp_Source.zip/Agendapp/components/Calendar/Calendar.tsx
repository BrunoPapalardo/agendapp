import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Calendar, dateFnsLocalizer, Views, SlotInfo, Messages } from 'react-big-calendar'; // Import Messages type
import { format, parse, startOfWeek, getDay, addMinutes, setHours, setMinutes, setSeconds, setMilliseconds, isBefore, isEqual, isAfter, startOfDay, endOfDay, eachMinuteOfInterval, areIntervalsOverlapping, parseISO } from 'date-fns';
import ptBR from 'date-fns/locale/pt-BR';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import { Loader2, AlertCircle, X } from 'lucide-react';
import { useSession } from 'next-auth/react'; // Import useSession to get user ID

// Interfaces matching Prisma schema (can be moved to a types file)
interface Service {
  id: number;
  name: string;
  duration: number; // Duration in minutes
  prepareTime: number; // in minutes
  intervalTime: number; // in minutes
  price: number;
}

interface Employee {
  id: number;
  name: string;
  image: string | null;
  // services: Service[]; // Relation might not be needed here if service is passed
}

interface BusinessHours {
  id: number;
  dayOfWeek: number; // 0 (Sunday) - 6 (Saturday)
  startTime: string; // "HH:mm"
  endTime: string; // "HH:mm"
  employeeId: number | null;
}

interface Appointment {
  id: number;
  dateTime: string; // ISO string
  serviceDuration: number; // Duration in minutes
  employeeId: number;
  companyId: number;
  userId: number;
}

// Configuração do localizador para português
const locales = { 'pt-BR': ptBR };
const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek: (date) => startOfWeek(date, { locale: ptBR }),
  getDay,
  locales,
});

// Helper to format duration (assuming duration is in minutes)
const formatDuration = (minutes: number) => {
    if (!minutes) return '0min';
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    let durationStr = '';
    if (h > 0) durationStr += `${h}h `;
    if (m > 0) durationStr += `${m}min`;
    return durationStr.trim() || '0min';
};

// Define messages object outside the component
const calendarMessages: Messages = {
  week: 'Semana',
  day: 'Dia',
  previous: '<',
  next: '>',
  today: 'Hoje',
  month: 'Mês',
  agenda: 'Agenda',
  noEventsInRange: 'Não há horários disponíveis neste período.',
  showMore: (total: number) => `+${total} mais`,
};

// Props for the modal
interface AgendaModalProps {
  isOpen: boolean; // Renamed from showCalendar for clarity
  onClose: () => void; // Renamed from setShowCalendar
  companyId: number;
  service: Service | null;
  employees: Employee[];
  businessHours: BusinessHours[];
  selectedEmployeeId?: number | null; // Optional pre-selected employee
}

export default function AgendaModal({ 
  isOpen, 
  onClose, 
  companyId, 
  service, 
  employees, 
  businessHours, 
  selectedEmployeeId: initialSelectedEmployeeId
}: AgendaModalProps) {
  const { data: session } = useSession(); // Get session data
  const userId = session?.user?.id; // Extract user ID (needs adjustment based on your session structure)

  const [view, setView] = useState<any>(Views.DAY); // Default to Day view for mobile-first
  const [date, setDate] = useState(new Date());
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<number | null>(initialSelectedEmployeeId || null);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [availableSlots, setAvailableSlots] = useState<Date[]>([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [loadingAppointments, setLoadingAppointments] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [bookingStatus, setBookingStatus] = useState<{ loading: boolean; error: string | null; success: boolean }>({ loading: false, error: null, success: false });

  // Filter employees who can perform the selected service (if relation exists or logic is defined)
  const availableEmployees = useMemo(() => employees, [employees]);

  // Set default employee if only one is available or if pre-selected
  useEffect(() => {
    if (initialSelectedEmployeeId) {
        setSelectedEmployeeId(initialSelectedEmployeeId);
    } else if (availableEmployees.length === 1) {
      setSelectedEmployeeId(availableEmployees[0].id);
    } else {
      setSelectedEmployeeId(null); // Reset if multiple or none and no pre-selection
    }
  }, [availableEmployees, initialSelectedEmployeeId]);

  // Fetch existing appointments when company, employee, or date range changes
  const fetchAppointments = useCallback(async () => {
    if (!companyId || !selectedEmployeeId) return;
    setLoadingAppointments(true);
    setError(null);
    try {
      // Define date range for fetching (e.g., current view)
      const url = `/api/appointments?companyId=${companyId}&employeeId=${selectedEmployeeId}`;
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error('Falha ao buscar agendamentos existentes.');
      }
      const data: Appointment[] = await response.json();
      setAppointments(data);
    } catch (err: any) {
      setError(err.message);
      setAppointments([]);
    } finally {
      setLoadingAppointments(false);
    }
  }, [companyId, selectedEmployeeId]);

  useEffect(() => {
    fetchAppointments();
  }, [fetchAppointments]);

  // Calculate available slots
  const calculateAvailableSlots = useCallback(() => {
    if (!service || !selectedEmployeeId || businessHours.length === 0) {
      setAvailableSlots([]);
      return;
    }
    setLoadingSlots(true);

    const slots: Date[] = [];
    const today = startOfDay(new Date());
    // Calculate range based on current date and view (e.g., 7 days for week view, 1 day for day view)
    const rangeStart = view === Views.WEEK ? startOfWeek(date, { locale: ptBR }) : startOfDay(date);
    const rangeEnd = view === Views.WEEK ? addMinutes(rangeStart, 7 * 24 * 60) : addMinutes(rangeStart, 24 * 60);

    // Filter business hours for the selected employee or general company hours
    const relevantBusinessHours = businessHours.filter(
      bh => bh.employeeId === selectedEmployeeId || bh.employeeId === null
    );

    // Iterate through days in the current range
    let currentDay = rangeStart;
    while (isBefore(currentDay, rangeEnd)) {
      const dayOfWeek = getDay(currentDay);
      const dayBusinessHours = relevantBusinessHours.filter(bh => bh.dayOfWeek === dayOfWeek);

      if (isBefore(currentDay, today)) { // Skip past days
         currentDay = addMinutes(currentDay, 24 * 60);
         continue;
      }

      dayBusinessHours.forEach(bh => {
        const [startHour, startMinute] = bh.startTime.split(':').map(Number);
        const [endHour, endMinute] = bh.endTime.split(':').map(Number);

        let slotStart = setMilliseconds(setSeconds(setMinutes(setHours(currentDay, startHour), startMinute), 0), 0);
        const dayEnd = setMilliseconds(setSeconds(setMinutes(setHours(currentDay, endHour), endMinute), 0), 0);

        // Iterate through possible start times within business hours
        while (isBefore(slotStart, dayEnd)) {
          const slotEnd = addMinutes(slotStart, service.duration);
          const bookingEnd = addMinutes(slotEnd, service.intervalTime); // Includes interval for next booking

          // Check if slot is in the future
          const now = new Date();
          if (isBefore(slotStart, now)) {
              slotStart = addMinutes(slotStart, 15); // Check next 15-min interval
              continue;
          }

          // Check if slot ends after business hours for the day
          if (isAfter(bookingEnd, dayEnd)) {
            break; // No more slots possible in this block
          }

          // Check for overlaps with existing appointments
          const overlap = appointments.some(app => {
            const appStart = parseISO(app.dateTime);
            const appEnd = addMinutes(appStart, app.serviceDuration);
            // Check overlap considering the full booking time (service + interval)
            return areIntervalsOverlapping(
              { start: slotStart, end: bookingEnd }, 
              { start: appStart, end: appEnd }, 
              { inclusive: false } // Intervals are exclusive at the end
            );
          });

          if (!overlap) {
            slots.push(slotStart);
          }

          // Move to the next potential slot start time (e.g., every 15 minutes)
          slotStart = addMinutes(slotStart, 15); 
        }
      });

      currentDay = addMinutes(currentDay, 24 * 60); // Move to the next day
    }

    setAvailableSlots(slots);
    setLoadingSlots(false);
  }, [service, selectedEmployeeId, businessHours, appointments, date, view]); // Added view dependency

  useEffect(() => {
    calculateAvailableSlots();
  }, [calculateAvailableSlots]);

  // Convert appointments and available slots to Big Calendar events
  const events = useMemo(() => {
    const existingEvents = appointments.map(app => {
      const start = parseISO(app.dateTime);
      const end = addMinutes(start, app.serviceDuration);
      return {
        id: `app-${app.id}`,
        title: 'Ocupado',
        start,
        end,
        allDay: false,
        isAvailable: false,
      };
    });

    const availableEvents = availableSlots.map((slotStart, index) => {
        const slotEnd = addMinutes(slotStart, service?.duration || 0);
        return {
            id: `slot-${index}`,
            title: 'Disponível',
            start: slotStart,
            end: slotEnd,
            allDay: false,
            isAvailable: true,
        };
    });

    return [...existingEvents, ...availableEvents];
  }, [appointments, availableSlots, service]);

  const handleSelectSlot = async (slotInfo: SlotInfo | { start: Date, end: Date }) => {
    // Check if the selected slot corresponds to an available slot event
    const selectedStart = slotInfo.start;
    const isSlotAvailable = availableSlots.some(slot => isEqual(slot, selectedStart));

    if (!isSlotAvailable || !service || !selectedEmployeeId || !userId) {
        if (!userId) setError("Você precisa estar logado para agendar.");
        else setError("Este horário não está disponível ou dados incompletos.");
        return;
    }

    setBookingStatus({ loading: true, error: null, success: false });
    setError(null);

    try {
        const response = await fetch('/api/appointments', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                dateTime: selectedStart.toISOString(),
                userId: userId, // Use actual logged-in user ID
                employeeId: selectedEmployeeId,
                companyId: companyId,
                serviceId: service.id,
                serviceDuration: service.duration,
            }),
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Falha ao criar agendamento.');
        }

        setBookingStatus({ loading: false, error: null, success: true });
        // Refresh appointments and slots
        fetchAppointments();
        // Optionally close modal after a delay
        setTimeout(() => {
            onClose(); // Use onClose prop
            setBookingStatus({ loading: false, error: null, success: false }); // Reset status
        }, 2000);

    } catch (err: any) {
        console.error("Booking error:", err);
        setBookingStatus({ loading: false, error: err.message, success: false });
    }
};

  // Style events based on availability
  const eventStyleGetter = (event: any) => {
    const style = {
      backgroundColor: event.isAvailable ? '#34D399' : '#EF4444', // Green for available, Red for busy
      borderRadius: '5px',
      opacity: event.isAvailable ? 0.8 : 0.6,
      color: 'white',
      border: '0px',
      display: 'block',
      fontSize: '0.7rem', // Slightly smaller font size for events
      padding: '1px 3px', // Reduced padding
    };
    return { style };
  };

  // Reset state when modal is closed
  useEffect(() => {
    if (!isOpen) {
      setDate(new Date());
      // Keep initial selected employee if provided, otherwise reset based on availability
      setSelectedEmployeeId(initialSelectedEmployeeId || (availableEmployees.length === 1 ? availableEmployees[0].id : null));
      setAppointments([]);
      setAvailableSlots([]);
      setError(null);
      setBookingStatus({ loading: false, error: null, success: false });
    }
  }, [isOpen, availableEmployees, initialSelectedEmployeeId]);

  // Adjust calendar view based on screen size
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setView(Views.DAY); // Switch to Day view on small screens
      } else {
        setView(Views.WEEK); // Switch back to Week view on larger screens
      }
    };
    handleResize(); // Initial check
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  if (!isOpen || !service) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-70 z-50 p-2 sm:p-4">
      {/* Adjusted max-h and max-w for better mobile fit */}
      <div className="bg-white text-gray-900 rounded-lg shadow-xl max-h-[90vh] w-full max-w-sm sm:max-w-md md:max-w-4xl flex flex-col">
        {/* Header */}
        <div className="p-3 sm:p-4 border-b flex justify-between items-center flex-shrink-0">
          <div>
            <h2 className="text-base sm:text-xl font-bold text-purple-700">Agendar Serviço</h2>
            <p className='text-xs sm:text-sm text-gray-600'>{service.name} ({formatDuration(service.duration)})</p>
          </div>
          <button
            className="text-gray-500 hover:text-red-600 p-1 -mr-1" 
            onClick={onClose} // Use onClose prop
            aria-label="Fechar modal"
          >
            <X className="h-5 w-5 sm:h-6 sm:w-6" />
          </button>
        </div>

        {/* Employee Selection */}
        {availableEmployees.length > 1 && (
          <div className="p-3 sm:p-4 border-b flex-shrink-0">
            <label htmlFor="employeeSelect" className="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Selecione o Profissional:</label>
            <select
              id="employeeSelect"
              value={selectedEmployeeId ?? ''}
              onChange={(e) => setSelectedEmployeeId(Number(e.target.value))}
              className="w-full p-1.5 sm:p-2 border border-gray-300 rounded-md focus:ring-purple-500 focus:border-purple-500 text-xs sm:text-sm"
              disabled={bookingStatus.loading || bookingStatus.success}
            >
              <option value="" disabled>-- Escolha um profissional --</option>
              {availableEmployees.map(emp => (
                <option key={emp.id} value={emp.id}>{emp.name}</option>
              ))}
            </select>
          </div>
        )}

        {/* Calendar and Status Area */}
        <div className="p-2 sm:p-4 flex-1 overflow-y-auto">
          {!selectedEmployeeId && availableEmployees.length > 1 ? (
            <p className='text-center text-gray-500 py-6 sm:py-10 text-sm'>Por favor, selecione um profissional para ver os horários.</p>
          ) : loadingAppointments || loadingSlots ? (
            <div className="flex justify-center items-center h-full py-6 sm:py-10">
              <Loader2 className="h-6 w-6 sm:h-8 sm:w-8 animate-spin text-purple-600" />
              <p className="ml-2 text-gray-600 text-sm">Carregando horários...</p>
            </div>
          ) : error ? (
            <div className="text-center text-red-600 bg-red-50 p-3 sm:p-4 rounded-md text-sm">
              <AlertCircle className="h-5 w-5 sm:h-6 sm:w-6 mx-auto mb-2" />
              <p>{error}</p>
              <button onClick={fetchAppointments} className='mt-2 text-xs sm:text-sm text-purple-600 hover:underline'>Tentar novamente</button>
            </div>
          ) : bookingStatus.loading ? (
             <div className="text-center text-blue-600 bg-blue-50 p-3 sm:p-4 rounded-md text-sm">
                <Loader2 className="h-5 w-5 sm:h-6 sm:w-6 mx-auto mb-2 animate-spin" />
                <p>Confirmando seu agendamento...</p>
            </div>
          ) : bookingStatus.error ? (
             <div className="text-center text-red-600 bg-red-50 p-3 sm:p-4 rounded-md text-sm">
                <AlertCircle className="h-5 w-5 sm:h-6 sm:w-6 mx-auto mb-2" />
                <p>Erro no Agendamento: {bookingStatus.error}</p>
                <button onClick={() => setBookingStatus({ loading: false, error: null, success: false })} className='mt-2 text-xs sm:text-sm text-purple-600 hover:underline'>Tentar novamente</button>
            </div>
          ) : bookingStatus.success ? (
             <div className="text-center text-green-600 bg-green-50 p-3 sm:p-4 rounded-md text-sm">
                <p>Agendamento confirmado com sucesso!</p>
            </div>
          ) : (
            /* Adjusted height for better fit on mobile */
            <div className="h-[calc(80vh-180px)] sm:h-[calc(90vh-220px)] md:h-[500px]">
              <Calendar
                localizer={localizer}
                events={events}
                startAccessor="start"
                endAccessor="end"
                style={{ height: '100%' }}
                view={view}
                onView={(newView) => setView(newView)}
                date={date}
                onNavigate={(newDate) => setDate(newDate)}
                views={['week', 'day']} // Allow week and day views
                selectable={true} // Allow selecting slots
                onSelectSlot={handleSelectSlot} // Handle slot selection
                onSelectEvent={(event) => event.isAvailable ? handleSelectSlot(event) : {}} // Handle clicking on available event
                eventPropGetter={eventStyleGetter}
                messages={calendarMessages} // Pass the defined messages object
                culture='pt-BR'
                step={15} // Time slot interval
                timeslots={4} // Number of slots in an hour
                min={setHours(new Date(0), 7)} // Start time for the calendar view (e.g., 7 AM)
                max={setHours(new Date(0), 22)} // End time for the calendar view (e.g., 10 PM)
                dayLayoutAlgorithm="no-overlap"
                popup={true} // Use popup for overlapping events on small screens
                components={{
                    toolbar: (toolbarProps) => (
                        <div className="rbc-toolbar mb-2 flex flex-col sm:flex-row items-center">
                            <span className="rbc-btn-group">
                                <button type="button" onClick={() => toolbarProps.onNavigate('TODAY')}>{calendarMessages.today}</button>
                                <button type="button" onClick={() => toolbarProps.onNavigate('PREV')}>{calendarMessages.previous}</button>
                                <button type="button" onClick={() => toolbarProps.onNavigate('NEXT')}>{calendarMessages.next}</button>
                            </span>
                            <span className="rbc-toolbar-label flex-1 text-center my-1 sm:my-0 text-sm sm:text-base">
                                {toolbarProps.label}
                            </span>
                            <span className="rbc-btn-group">
                                {toolbarProps.views.map(viewName => (
                                    <button
                                        key={viewName}
                                        type="button"
                                        className={`${toolbarProps.view === viewName ? 'rbc-active' : ''} ${viewName === 'week' ? 'hidden sm:inline-block' : ''}`} // Hide week view button on small screens
                                        onClick={() => toolbarProps.onView(viewName)}
                                    >
                                        {calendarMessages[viewName as keyof Messages] || viewName}
                                    </button>
                                ))}
                            </span>
                        </div>
                    )
                }}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

