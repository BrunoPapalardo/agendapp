
'use client';

import { useSession } from "next-auth/react";
import React, { useState } from "react";
import Link from 'next/link';
import { Menu, User, X } from 'lucide-react'; // Changed Calendar to Menu for mobile toggle
import UserMenu from '../UserMenu/UserMenu'; // Componente do menu do usuário
import Image from "next/image";

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const { status } = useSession(); // Verifica autenticação

  return (
    <header className="bg-white shadow-sm fixed top-0 left-0 w-full z-50"> {/* Increased z-index */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16"> {/* Fixed height */}
          {/* Logo */}
          <Link href="/home" className="flex items-center gap-2">
            <Image
              src='/img/logo.png'
              alt='Agenday Logo'
              className="w-8 h-8 object-contain" // Use contain for logo
              width={32}
              height={32}
            />
            <span className="text-xl font-bold text-gray-900 hidden sm:inline">Agenday</span> {/* Hide text on small screens */}
          </Link>

          {/* Desktop Navigation (Optional - Add links here if needed) */}
          {/* <nav className="hidden md:flex space-x-4">
            <Link href="/explore" className="text-gray-600 hover:text-purple-600">Explorar</Link>
            <Link href="/about" className="text-gray-600 hover:text-purple-600">Sobre</Link>
          </nav> */}

          {/* User Menu Button */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="p-2 rounded-full flex justify-center items-center cursor-pointer transition duration-300 ease-in-out hover:bg-gray-100 active:scale-95"
            aria-label="Abrir menu do usuário"
          >
            <User className="h-6 w-6 text-purple-600"/> 
          </button>

          {/* User Menu Panel (Mobile) */}
          <UserMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} status={status} />
        </div>
      </div>
    </header>
  );
}

export default Header;
