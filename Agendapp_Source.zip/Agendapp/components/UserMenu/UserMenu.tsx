import { signOut, useSession } from "next-auth/react";
import React, { useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import { X, User, Settings, Calendar, LogOut } from "lucide-react";

interface UserMenuProps {
    isOpen: boolean;
    onClose: () => void;
    status: "authenticated" | "unauthenticated" | "loading";
}

const UserMenu: React.FC<UserMenuProps> = ({ isOpen, onClose, status }) => {
    const { data: session } = useSession();

    // Prevent background scrolling when menu is open
    useEffect(() => {
        document.body.style.overflow = isOpen ? "hidden" : "auto";
        
        // Cleanup function to ensure scrolling is re-enabled when component unmounts
        return () => {
            document.body.style.overflow = "auto";
        };
    }, [isOpen]);

    // Handle escape key to close menu
    useEffect(() => {
        const handleEscKey = (event: KeyboardEvent) => {
            if (event.key === 'Escape' && isOpen) {
                onClose();
            }
        };

        window.addEventListener('keydown', handleEscKey);
        return () => window.removeEventListener('keydown', handleEscKey);
    }, [isOpen, onClose]);

    if (!isOpen) return null;

    return (
        <div
            className="fixed inset-0 w-full h-full bg-black/50 z-[1000] flex justify-end"
            onClick={onClose}
            role="dialog"
            aria-modal="true"
            aria-labelledby="user-menu-title"
        >
            <motion.div
                initial={{ x: "100%" }}
                animate={{ x: isOpen ? "0%" : "100%" }}
                exit={{ x: "100%" }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
                className="w-[85%] max-w-[320px] h-full bg-white text-black flex flex-col p-4 sm:p-6 relative shadow-xl"
                onClick={(e) => e.stopPropagation()}
            >
                {/* Botão de Fechar */}
                <button
                    className="absolute top-3 right-3 text-gray-600 hover:text-gray-800 p-1 rounded-full hover:bg-gray-100"
                    onClick={onClose}
                    aria-label="Fechar menu"
                >
                    <X size={20} />
                </button>

                <h2 id="user-menu-title" className="sr-only">Menu do Usuário</h2>

                {status === "authenticated" ? (
                    <>
                        {/* Perfil do Usuário */}
                        <div className="flex flex-col items-center gap-3 border-b pb-4 mt-4">
                            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full overflow-hidden border-2 border-purple-500 bg-gray-100">
                                {session?.user.image ? (
                                    <Image
                                        src={session.user.image}
                                        alt={session.user.name || "Usuário"}
                                        className="w-full h-full object-cover"
                                        width={80}
                                        height={80}
                                        onError={(e) => {
                                            e.currentTarget.style.display = "none";
                                            e.currentTarget.parentElement?.classList.add("flex", "items-center", "justify-center");
                                            const parent = e.currentTarget.parentElement;
                                            if (parent) {
                                                const userIcon = document.createElement("div");
                                                userIcon.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-gray-400"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>';
                                                parent.appendChild(userIcon);
                                            }
                                        }}
                                    />
                                ) : (
                                    <div className="w-full h-full bg-gray-200 flex items-center justify-center text-gray-500">
                                        <User size={32} />
                                    </div>
                                )}
                            </div>
                            <div className="text-center">
                                <p className="text-base sm:text-lg font-semibold">Olá, {session?.user.name?.split(" ")[0] || "Usuário"} 👋</p>
                                <p className="text-xs sm:text-sm text-gray-500 mt-1">{session?.user.email}</p>
                            </div>
                        </div>

                        {/* Links do Menu */}
                        <nav className="mt-4">
                            <ul className="space-y-1 text-gray-700">
                                <li>
                                    <Link href="/profile" className="flex items-center py-3 px-2 rounded-lg hover:bg-gray-100 transition-colors">
                                        <User size={18} className="mr-3 text-purple-600" />
                                        <span>Perfil</span>
                                    </Link>
                                </li>
                                <li>
                                    <Link href="/schedule" className="flex items-center py-3 px-2 rounded-lg hover:bg-gray-100 transition-colors">
                                        <Calendar size={18} className="mr-3 text-purple-600" />
                                        <span>Minha agenda</span>
                                    </Link>
                                </li>
                                <li>
                                    <Link href="/settings" className="flex items-center py-3 px-2 rounded-lg hover:bg-gray-100 transition-colors">
                                        <Settings size={18} className="mr-3 text-purple-600" />
                                        <span>Configurações</span>
                                    </Link>
                                </li>
                            </ul>
                        </nav>
                        
                        {/* Logout Button */}
                        <div className="mt-auto pt-4 border-t">
                            <button
                                className="w-full flex items-center py-3 px-2 rounded-lg text-red-600 hover:bg-red-50 transition-colors"
                                onClick={() => signOut({ callbackUrl: "/" })}
                            >
                                <LogOut size={18} className="mr-3" />
                                <span>Sair</span>
                            </button>
                        </div>
                    </>
                ) : status === "loading" ? (
                    <div className="flex items-center justify-center h-40">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center h-40 p-4">
                        <Link
                            href="/login"
                            className="w-full flex justify-center items-center px-6 py-3 text-white bg-purple-600 rounded-md hover:bg-purple-700 transition"
                        >
                            Entrar
                        </Link>
                        <p className="mt-4 text-sm text-gray-600 text-center">
                            Ainda não tem uma conta?{" "}
                            <Link href="/register" className="text-purple-600 hover:underline font-medium">
                                Cadastre-se
                            </Link>
                        </p>
                    </div>
                )}
                
                {/* Footer with version info */}
                <div className="mt-4 pt-2 text-xs text-center text-gray-400">
                    Agenday v1.0
                </div>
            </motion.div>
        </div>
    );
};

export default UserMenu;
