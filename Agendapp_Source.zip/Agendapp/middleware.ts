import { NextResponse } from 'next/server';
import { withAuth } from 'next-auth/middleware';

// Middleware para proteger rotas que exigem autenticação
export default withAuth(
  function middleware(req) {
    // Continua normalmente se o usuário estiver autenticado
    return NextResponse.next();
  },
  {
    callbacks: {
      authorized: ({ token }) => !!token, // Verifica se o token existe
    },
    // Lista de rotas protegidas que exigem autenticação
    pages: {
      signIn: '/login', // Redireciona para /login se não estiver autenticado
    },
  }
);

// Configuração de quais rotas devem ser protegidas
export const config = {
  // Protege rotas específicas que exigem autenticação
  matcher: [
    '/booking/:path*',  // Rotas de agendamento
    '/profile/:path*',  // Rotas de perfil
    '/schedule/:path*', // Rotas de agenda pessoal
    '/settings/:path*', // Rotas de configurações
    '/admin/:path*',    // Rotas de administração
  ],
};
