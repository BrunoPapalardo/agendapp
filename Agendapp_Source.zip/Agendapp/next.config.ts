import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "**", // Aceita qualquer host externo
      },
    ],
  },
  env: {
    NEXTAUTH_SECRET: process.env.NEXTAUTH_SECRET, // Expõe o NEXTAUTH_SECRET para o Next.js
  },
  eslint: {
    // Desativa a verificação do ESLint durante o build
    ignoreDuringBuilds: true,
  },
  typescript: {
    // Também desativa a verificação de tipos do TypeScript durante o build
    ignoreBuildErrors: true,
  },
};

export default nextConfig;
