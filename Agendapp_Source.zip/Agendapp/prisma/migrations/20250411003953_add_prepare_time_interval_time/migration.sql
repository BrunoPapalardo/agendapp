-- AlterTable
ALTER TABLE "Service" ADD COLUMN     "customFields" JSONB;
