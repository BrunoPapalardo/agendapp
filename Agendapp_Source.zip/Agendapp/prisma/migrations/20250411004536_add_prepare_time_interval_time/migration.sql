-- AlterTable
ALTER TABLE "Service" ALTER COLUMN "image" DROP NOT NULL;
